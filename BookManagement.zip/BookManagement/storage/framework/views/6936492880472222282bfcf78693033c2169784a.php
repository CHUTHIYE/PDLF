<!DOCTYPE html>
<html>
<head>
    <title>Create Book</title>
</head>
<body>
    <h1>Create Book</h1>
    <form action="<?php echo e(route('books.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" required>
        <br>

        <label for="authorid">Author ID:</label>
        <input type="number" name="authorid" id="authorid" required>
        <br>

        <label for="ISBN">ISBN:</label>
        <input type="text" name="ISBN" id="ISBN" required>
        <br>

        <label for="pub_year">Publication Year:</label>
        <input type="number" name="pub_year" id="pub_year" required>
        <br>

        <button type="submit">Create</button>
    </form>
</body>
</html>
<?php /**PATH C:\BookManagement\resources\views/books/create.blade.php ENDPATH**/ ?>